from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

# Lab 10: Simple Dictionary based Knowledge Base
knowledge_base = {
    "hi": "Hello! How can I help you with university admissions?",
    "deadline": "The admission deadline is August 25, 2026.",
    "fee": "The semester fee for BSCS is 120,000 PKR.",
    "requirements": "You need 60% marks in Intermediate for admission.",
    "scholarship": "Yes, merit-based scholarships are available for 85%+ marks."
}

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/get_response', methods=['POST'])
def get_response():
    user_query = request.form['msg'].lower() # User ka sawal lowercase mein
    
    # Lab 10 Logic: Simple Keyword Matching
    response = "I am sorry, I don't understand that. Please ask about fee, deadline, or requirements."
    
    for key in knowledge_base:
        if key in user_query:
            response = knowledge_base[key]
            break
            
    return jsonify({"reply": response})

if __name__ == "__main__":
    app.run(debug=True, port=5001) # Port change ki hai taake Lab 12 se clash na ho